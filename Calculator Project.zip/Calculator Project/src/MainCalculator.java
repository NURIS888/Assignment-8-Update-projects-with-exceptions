// MainCalculator.java
public class MainCalculator {
    public static void main(String[] args) {
        try {
            // Performing a division operation where the denominator is zero
            double result = Calculator.divide(10, 0);

        } catch (DivisionByZeroException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
