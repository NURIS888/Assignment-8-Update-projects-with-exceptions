public class Calculator {
    public static double divide(double dividend, double divisor) throws DivisionByZeroException {
        if (divisor == 0) {
            throw new DivisionByZeroException("Cannot divide by zero");
        } else {
            return dividend / divisor;
        }
    }
}
