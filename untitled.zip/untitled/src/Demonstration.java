public class Main {
    public static void main(String[] args) {
        try {
            // Creating an Account object with an initial balance of 1000
            Account account = new Account(1000);

            // Trying to withdraw an amount larger than the balance (e.g., 1500)
            account.withdraw(1500);

        } catch (InsufficientBalanceException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
